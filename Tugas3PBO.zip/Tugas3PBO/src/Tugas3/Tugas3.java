package Tugas3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Tugas3 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // Data login
        String username = "Admin";
        String password = "123";

        System.out.print("Masukkan username: ");
        String inputUser = br.readLine();
        System.out.print("Masukkan password: ");
        String inputPass = br.readLine();

        if (inputUser.equals(username) && inputPass.equals(password)) {
            double hargaTiketPesawat, hargaKamarHotel;
            int jumlahPenumpang, jumlahKamar;

            System.out.print("Masukkan harga tiket pesawat: ");
            hargaTiketPesawat = Double.parseDouble(br.readLine());
            System.out.print("Masukkan jumlah penumpang: ");
            jumlahPenumpang = Integer.parseInt(br.readLine());
            System.out.print("Masukkan harga kamar hotel: ");
            hargaKamarHotel = ;
            System.out.print("Masukkan jumlah kamar: ");
            jumlahKamar = scanner.nextInt();

            double hargaTiket = hargaTiketPesawat * jumlahPenumpang;
            double asuransi = jumlahPenumpang * 29000;
            double totalHargaTiket = hargaTiket + asuransi;

            double diskon = 0.45 * hargaKamarHotel;
            double totalBiayaHotel = (hargaKamarHotel - diskon) * jumlahKamar;

            System.out.println("Total Harga Tiket Pesawat: " + totalHargaTiket);
            System.out.println("Total Biaya Kamar Hotel: " + totalBiayaHotel);
        } else {
            System.out.println("Login gagal. Username atau password salah.");
        }
    }
}
